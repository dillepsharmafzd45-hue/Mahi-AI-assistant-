package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.offline.OfflineEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Mahi AI", appName)
  }

  @Test
  fun `offline engine evaluates math correctly`() {
    val result = OfflineEngine.processQuery("calculate 25 * 4")
    assertTrue(result.contains("100"))
  }

  @Test
  fun `offline engine responds to greetings in Hindi`() {
    val result = OfflineEngine.processQuery("नमस्ते माही")
    assertTrue(result.contains("नमस्ते"))
  }
}
