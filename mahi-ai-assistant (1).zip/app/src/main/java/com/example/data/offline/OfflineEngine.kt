package com.example.data.offline

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object OfflineEngine {

    fun isOfflineNoteCommand(query: String): Pair<Boolean, String> {
        val lower = query.trim().lowercase(Locale.ROOT)
        val prefixes = listOf("note:", "note down:", "save note:", "याद रखना:", "नोट:")
        for (prefix in prefixes) {
            if (lower.startsWith(prefix)) {
                return Pair(true, query.substring(prefix.length).trim())
            }
        }
        if (lower.startsWith("note ") || lower.startsWith("save note ")) {
            return Pair(true, query.replaceFirst(Regex("^(note|save note)\\s+", RegexOption.IGNORE_CASE), "").trim())
        }
        return Pair(false, "")
    }

    fun processQuery(input: String): String {
        val query = input.trim()
        val lower = query.lowercase(Locale.ROOT)

        // 1. Check Math calculation
        val mathResult = tryEvaluateMath(lower)
        if (mathResult != null) {
            return mathResult
        }

        // 2. Check Date & Time
        if (containsAny(lower, "time", "समय", "kitna baje", "samay", "ghadi")) {
            val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            return if (isHindiText(query)) {
                "अभी समय $timeStr हुआ है।"
            } else {
                "The current time is $timeStr."
            }
        }

        if (containsAny(lower, "date", "tarikh", "tareekh", "दिनांक", "तारीख", "aaj ka din", "today")) {
            val dateStr = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(Date())
            return if (isHindiText(query)) {
                "आज की तारीख है: $dateStr"
            } else {
                "Today is $dateStr."
            }
        }

        // 3. Greetings & Identity
        if (containsAny(lower, "who are you", "who r u", "kaun ho", "कौन हो", "tum kaun ho", "aap kaun ho", "intro")) {
            return if (isHindiText(query) || containsAny(lower, "hindi", "kaun")) {
                "नमस्ते! मैं माही हूँ (Mahi AI Assistant) — आपकी स्मार्ट वॉइस और टेक्स्ट साथी। मैं हिंदी और अंग्रेजी दोनों में आपकी मदद कर सकती हूँ। ऑफ़लाइन मोड में भी मेरी त्वरित सुविधाएं उपलब्ध हैं।"
            } else {
                "Hello! I am Mahi AI Assistant — your intelligent voice and text companion. I speak both English and Hindi fluently, and I can assist you online and offline!"
            }
        }

        if (containsAny(lower, "namaste", "namaskar", "नमस्ते", "pranam", "radhe radhe", "jai shree ram")) {
            return "नमस्ते! आपका स्वागत है। मैं माही हूँ, आपकी क्या सहायता कर सकती हूँ?"
        }

        if (containsAny(lower, "hello", "hi mahi", "hey mahi", "hi", "hey")) {
            return "Hey there! I am Mahi. How can I help you today? आप मुझसे हिंदी या अंग्रेजी में कुछ भी पूछ सकते हैं।"
        }

        if (containsAny(lower, "how are you", "kaise ho", "kaisi ho", "kya haal hai", "aap kaisi ho")) {
            return if (isHindiText(query) || lower.contains("kaise") || lower.contains("kaisi")) {
                "मैं बहुत अच्छी हूँ, शुक्रिया! आशा है आपका दिन भी शानदार बीत रहा होगा। बताइए, आज क्या करना है?"
            } else {
                "I am doing fantastic, thank you! Ready to assist you in English or Hindi. How can I help you right now?"
            }
        }

        // 4. Capabilities / Help
        if (containsAny(lower, "kya kar sakti ho", "features", "capabilities", "what can you do", "help")) {
            return if (isHindiText(query) || lower.contains("kya")) {
                "मैं निम्नलिखित कार्य कर सकती हूँ:\n" +
                        "• वॉइस या टेक्स्ट से हिंदी और इंग्लिश में बातचीत\n" +
                        "• प्रश्नों के उत्तर और जानकारी\n" +
                        "• ऑफ़लाइन गणित और समय/तारीख गणना\n" +
                        "• ऑफ़लाइन वॉयस नोट्स सुरक्षित रखना\n" +
                        "• मोटिवेशनल विचार और त्वरित सहायता"
            } else {
                "Here is what I can do for you:\n" +
                        "• Natural conversation in Hindi & English via Voice & Text\n" +
                        "• Instant Gemini AI powered reasoning (when connected)\n" +
                        "• Offline arithmetic, notes vault & smart answers\n" +
                        "• Spoken voice replies with real-time audio visualization"
            }
        }

        // 5. Motivation / Quotes / Shayari
        if (containsAny(lower, "quote", "motivat", "shayari", "vichar", "suvichar", "प्रेरणा", "शायरी")) {
            val quotesHindi = listOf(
                "\"लहरों से डर कर नौका पार नहीं होती, कोशिश करने वालों की कभी हार नहीं होती।\"",
                "\"मंजिल उन्हीं को मिलती है, जिनके सपनों में जान होती है; पंखों से कुछ नहीं होता, हौसलों से उड़ान होती है।\"",
                "\"विश्वास वह शक्ति है जिससे उजड़ी हुई दुनिया में भी प्रकाश किया जा सकता है।\""
            )
            val quotesEnglish = listOf(
                "\"The future belongs to those who believe in the beauty of their dreams.\" — Eleanor Roosevelt",
                "\"Success is not final, failure is not fatal: it is the courage to continue that counts.\" — Winston Churchill",
                "\"Do what you can, with what you have, where you are.\" — Theodore Roosevelt"
            )
            return if (isHindiText(query) || lower.contains("shayari") || lower.contains("vichar")) {
                quotesHindi.random()
            } else {
                quotesEnglish.random()
            }
        }

        // 6. Default Offline Fallback
        return if (isHindiText(query)) {
            "आप अभी ऑफ़लाइन हैं। मैंने आपका संदेश नोट कर लिया है। सामान्य जानकारी, गणित, तारीख-समय या नोट्स के लिए ऑफ़लाइन कमांड उपलब्ध हैं। इंटरनेट जुड़ते ही जेमिनी AI से गहरा उत्तर मिल जाएगा।"
        } else {
            "You are currently in Offline Mode. I've recorded your query. I can answer math, time/date, quotes, and save local notes offline. Connect to the internet for full Gemini 3.5 Flash intelligence!"
        }
    }

    private fun isHindiText(text: String): Boolean {
        for (char in text) {
            val block = Character.UnicodeBlock.of(char)
            if (block == Character.UnicodeBlock.DEVANAGARI) {
                return true
            }
        }
        return false
    }

    private fun containsAny(text: String, vararg keywords: String): Boolean {
        return keywords.any { text.contains(it) }
    }

    private fun tryEvaluateMath(text: String): String? {
        val clean = text.replace("what is", "")
            .replace("calculate", "")
            .replace("kya hoga", "")
            .replace("kitna hoga", "")
            .replace("ka man", "")
            .trim()

        val pattern = Regex("([0-9]+(?:\\.[0-9]+)?)\\s*([+\\-*/xX^%])\\s*([0-9]+(?:\\.[0-9]+)?)")
        val match = pattern.find(clean) ?: return null

        val (num1Str, op, num2Str) = match.destructured
        val num1 = num1Str.toDoubleOrNull() ?: return null
        val num2 = num2Str.toDoubleOrNull() ?: return null

        val result = when (op) {
            "+", "plus" -> num1 + num2
            "-", "minus" -> num1 - num2
            "*", "x", "X", "multiply" -> num1 * num2
            "/", "divide" -> if (num2 != 0.0) num1 / num2 else Double.NaN
            "%" -> num1 % num2
            "^" -> Math.pow(num1, num2)
            else -> return null
        }

        if (result.isNaN()) {
            return "Zero se divide nahi kiya ja sakta (Division by zero is undefined)."
        }

        val formatted = if (result % 1.0 == 0.0) {
            result.toLong().toString()
        } else {
            String.format(Locale.US, "%.2f", result)
        }

        return "Calculation Result: $num1 $op $num2 = $formatted"
    }
}
