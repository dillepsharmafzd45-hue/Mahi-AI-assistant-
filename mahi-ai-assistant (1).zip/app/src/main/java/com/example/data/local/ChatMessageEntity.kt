package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val text: String,
    val sender: String, // "USER" or "MAHI"
    val timestamp: Long = System.currentTimeMillis(),
    val language: String = "auto",
    val isOffline: Boolean = false,
    val isSynced: Boolean = true
)

@Entity(tableName = "offline_notes")
data class OfflineNoteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String,
    val createdAt: Long = System.currentTimeMillis()
)
