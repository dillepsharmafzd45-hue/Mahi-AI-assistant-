package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [ChatMessageEntity::class, OfflineNoteEntity::class], version = 1, exportSchema = false)
abstract class MahiDatabase : RoomDatabase() {
    abstract fun mahiDao(): MahiDao

    companion object {
        @Volatile
        private var INSTANCE: MahiDatabase? = null

        fun getDatabase(context: Context): MahiDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MahiDatabase::class.java,
                    "mahi_ai_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
