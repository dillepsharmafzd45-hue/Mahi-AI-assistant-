package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.ModeStandby
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DeepWineContainer
import com.example.ui.theme.HologramPinkLight
import com.example.ui.theme.LightPinkGlow
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPinkGlow
import com.example.ui.theme.StandbyGray
import kotlin.math.sin

@Composable
fun VoiceVisualizerOrb(
    isPowerOn: Boolean,
    isListening: Boolean,
    isSpeaking: Boolean,
    isGenerating: Boolean,
    soundLevel: Float,
    size: Dp = 220.dp,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_anim")

    // Ambient rotation
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    // Breathing pulse
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isSpeaking || isListening) 600 else 1800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    // Wave oscillation
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )

    val effectiveScale = when {
        !isPowerOn -> 0.88f
        isListening -> pulse + (soundLevel * 0.15f)
        isSpeaking -> pulse * 1.06f
        isGenerating -> pulse
        else -> pulse
    }

    Box(
        modifier = modifier
            .size(size)
            .scale(effectiveScale),
        contentAlignment = Alignment.Center
    ) {
        // Outer pulsing canvas with soundwaves and glowing rings
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val baseRadius = this.size.minDimension / 2f

            if (!isPowerOn) {
                // Dim standby ring
                drawCircle(
                    color = StandbyGray.copy(alpha = 0.25f),
                    radius = baseRadius * 0.75f,
                    center = center,
                    style = Stroke(width = 2.dp.toPx())
                )
                return@Canvas
            }

            // Glow aura
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        NeonPink.copy(alpha = if (isSpeaking || isListening) 0.5f else 0.22f),
                        DeepWineContainer.copy(alpha = 0.15f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius
                ),
                radius = baseRadius,
                center = center
            )

            // Dynamic ripples
            val rippleCount = 3
            for (i in 0 until rippleCount) {
                val rippleRadius = baseRadius * (0.6f + (i * 0.14f))
                val alpha = (0.5f - (i * 0.12f)).coerceIn(0.1f, 0.6f)
                drawCircle(
                    color = NeonPinkGlow.copy(alpha = alpha),
                    radius = rippleRadius,
                    center = center,
                    style = Stroke(width = (1.5f + i).dp.toPx())
                )
            }

            // If listening or speaking, draw dynamic soundwave bars around the circle
            if (isListening || isSpeaking) {
                val barCount = 28
                val angleStep = (2 * Math.PI / barCount).toFloat()
                val innerR = baseRadius * 0.58f
                val amplitude = if (isListening) (16.dp.toPx() * (0.4f + soundLevel)) else 20.dp.toPx()

                for (b in 0 until barCount) {
                    val angle = b * angleStep + (if (isGenerating) rotation else 0f)
                    val waveOffset = (sin(angle * 3 + wavePhase) + 1f) / 2f
                    val barHeight = amplitude * waveOffset

                    val startX = center.x + innerR * kotlin.math.cos(angle)
                    val startY = center.y + innerR * kotlin.math.sin(angle)
                    val endX = center.x + (innerR + barHeight) * kotlin.math.cos(angle)
                    val endY = center.y + (innerR + barHeight) * kotlin.math.sin(angle)

                    drawLine(
                        color = if (b % 2 == 0) NeonPink else LightPinkGlow,
                        start = Offset(startX, startY),
                        end = Offset(endX, endY),
                        strokeWidth = 2.5.dp.toPx()
                    )
                }
            }
        }

        // Inner glowing core orb
        Box(
            modifier = Modifier
                .size(size * 0.52f)
                .clip(CircleShape)
                .background(
                    if (isPowerOn) {
                        Brush.radialGradient(
                            listOf(
                                LightPinkGlow,
                                NeonPink,
                                DeepWineContainer,
                                CyberBlack
                            )
                        )
                    } else {
                        Brush.radialGradient(
                            listOf(
                                StandbyGray,
                                DarkSurfaceElevated,
                                CyberBlack
                            )
                        )
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = when {
                    !isPowerOn -> Icons.Default.ModeStandby
                    isListening -> Icons.Default.Mic
                    isSpeaking -> Icons.Default.GraphicEq
                    else -> Icons.Default.GraphicEq
                },
                contentDescription = "AI Core State",
                tint = if (isPowerOn) Color.White else StandbyGray,
                modifier = Modifier.size(size * 0.22f)
            )
        }
    }
}
