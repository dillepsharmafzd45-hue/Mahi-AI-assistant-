package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.MahiApplication
import com.example.data.local.ChatMessageEntity
import com.example.data.local.OfflineNoteEntity
import com.example.data.offline.OfflineEngine
import com.example.data.remote.GeminiApiClient
import com.example.data.remote.GeminiContent
import com.example.data.remote.GeminiGenerationConfig
import com.example.data.remote.GeminiPart
import com.example.data.remote.GeminiRequest
import com.example.speech.SpeechRecognizerHelper
import com.example.speech.TextToSpeechHelper
import com.example.util.NetworkMonitor
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class LanguageMode(val displayName: String, val code: String) {
    AUTO("Auto", "hi-IN"),
    HINDI("हिन्दी", "hi-IN"),
    ENGLISH("English", "en-IN"),
    HINGLISH("Hinglish", "hi-IN")
}

enum class MahiTab {
    VOICE_CORE,
    CONVERSATION,
    OFFLINE_VAULT,
    ABOUT
}

class MahiViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as MahiApplication
    private val dao = app.database.mahiDao()
    private val networkMonitor = NetworkMonitor(application)

    val messages: StateFlow<List<ChatMessageEntity>> = dao.getAllMessagesFlow()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val notes: StateFlow<List<OfflineNoteEntity>> = dao.getAllNotesFlow()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val isOnline: StateFlow<Boolean> = networkMonitor.isOnline
        .stateIn(viewModelScope, SharingStarted.Eagerly, networkMonitor.checkCurrentConnectivity())

    private val _isPowerOn = MutableStateFlow(true)
    val isPowerOn: StateFlow<Boolean> = _isPowerOn.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _voiceResponsesEnabled = MutableStateFlow(true)
    val voiceResponsesEnabled: StateFlow<Boolean> = _voiceResponsesEnabled.asStateFlow()

    private val _selectedLanguage = MutableStateFlow(LanguageMode.AUTO)
    val selectedLanguage: StateFlow<LanguageMode> = _selectedLanguage.asStateFlow()

    private val _activeTab = MutableStateFlow(MahiTab.VOICE_CORE)
    val activeTab: StateFlow<MahiTab> = _activeTab.asStateFlow()

    private val _spokenTextLive = MutableStateFlow("")
    val spokenTextLive: StateFlow<String> = _spokenTextLive.asStateFlow()

    private val _statusText = MutableStateFlow("Mahi is Ready • बोलिए या टाइप करें")
    val statusText: StateFlow<String> = _statusText.asStateFlow()

    val ttsHelper = TextToSpeechHelper(application)

    val speechHelper = SpeechRecognizerHelper(
        context = application,
        onResult = { recognizedText ->
            _spokenTextLive.value = ""
            if (recognizedText.isNotBlank()) {
                submitPrompt(recognizedText)
            }
        },
        onPartial = { partial ->
            _spokenTextLive.value = partial
        },
        onError = { error ->
            _spokenTextLive.value = ""
            _statusText.value = error
        }
    )

    val isListening: StateFlow<Boolean> = speechHelper.isListening
    val soundLevel: StateFlow<Float> = speechHelper.soundLevel
    val isSpeaking: StateFlow<Boolean> = ttsHelper.isSpeaking

    init {
        // Initial greeting if empty
        viewModelScope.launch {
            if (messages.value.isEmpty()) {
                dao.insertMessage(
                    ChatMessageEntity(
                        text = "नमस्ते! मैं माही हूँ (Mahi AI Assistant) — आपकी वॉइस साथी। मैं हिंदी और English दोनों समझती हूँ। मुझसे कुछ भी पूछिए!",
                        sender = "MAHI",
                        language = "hi",
                        isOffline = true
                    )
                )
            }
        }
    }

    fun togglePower() {
        val newState = !_isPowerOn.value
        _isPowerOn.value = newState
        if (!newState) {
            speechHelper.stopListening()
            ttsHelper.stop()
            _statusText.value = "Mahi is in Sleep Mode (पावर ऑफ)"
        } else {
            _statusText.value = "Mahi is Online & Ready (पावर ऑन)"
            if (_voiceResponsesEnabled.value) {
                ttsHelper.speak("नमस्ते, माही चालू हो गई है।")
            }
        }
    }

    fun toggleListening() {
        if (!_isPowerOn.value) {
            _statusText.value = "Mahi is in Sleep Mode. Turn ON power first."
            return
        }

        if (speechHelper.isListening.value) {
            speechHelper.stopListening()
            _statusText.value = "Listening paused"
        } else {
            ttsHelper.stop()
            _statusText.value = "Listening in ${_selectedLanguage.value.displayName}…"
            speechHelper.startListening(_selectedLanguage.value.code)
        }
    }

    fun toggleVoiceResponses() {
        val newState = !_voiceResponsesEnabled.value
        _voiceResponsesEnabled.value = newState
        if (!newState) {
            ttsHelper.stop()
        }
    }

    fun setLanguage(mode: LanguageMode) {
        _selectedLanguage.value = mode
    }

    fun setActiveTab(tab: MahiTab) {
        _activeTab.value = tab
    }

    fun stopSpeaking() {
        ttsHelper.stop()
    }

    fun submitPrompt(prompt: String) {
        val trimmed = prompt.trim()
        if (trimmed.isBlank() || !_isPowerOn.value) return

        viewModelScope.launch {
            // 1. Save User Message
            dao.insertMessage(
                ChatMessageEntity(
                    text = trimmed,
                    sender = "USER",
                    language = detectLanguageTag(trimmed)
                )
            )

            // 2. Check for offline note command
            val (isNote, noteContent) = OfflineEngine.isOfflineNoteCommand(trimmed)
            if (isNote && noteContent.isNotBlank()) {
                dao.insertNote(
                    OfflineNoteEntity(
                        title = noteContent.take(30),
                        content = noteContent
                    )
                )
                val reply = "नोट ऑफ़लाइन सुरक्षित कर लिया गया है: \"$noteContent\""
                dao.insertMessage(
                    ChatMessageEntity(
                        text = reply,
                        sender = "MAHI",
                        isOffline = true
                    )
                )
                if (_voiceResponsesEnabled.value) {
                    ttsHelper.speak(reply)
                }
                _statusText.value = "Note saved locally"
                return@launch
            }

            // 3. Process online vs offline
            _isGenerating.value = true
            _statusText.value = "Mahi is thinking…"

            val apiKey = GeminiApiClient.getApiKey()
            val hasValidKey = apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY"

            if (isOnline.value && hasValidKey) {
                try {
                    // Send to Gemini
                    val systemPrompt = buildSystemPrompt()
                    val contentsList = mutableListOf<GeminiContent>()

                    // Include last 4 turns for conversational context
                    val history = messages.value.takeLast(6)
                    for (msg in history) {
                        val role = if (msg.sender == "USER") "user" else "model"
                        contentsList.add(
                            GeminiContent(
                                role = role,
                                parts = listOf(GeminiPart(text = msg.text))
                            )
                        )
                    }
                    contentsList.add(
                        GeminiContent(
                            role = "user",
                            parts = listOf(GeminiPart(text = trimmed))
                        )
                    )

                    val request = GeminiRequest(
                        contents = contentsList,
                        systemInstruction = GeminiContent(parts = listOf(GeminiPart(text = systemPrompt))),
                        generationConfig = GeminiGenerationConfig(
                            temperature = 0.7f,
                            maxOutputTokens = 800
                        )
                    )

                    val response = GeminiApiClient.service.generateContent(apiKey, request)
                    val replyText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text

                    if (!replyText.isNullOrBlank()) {
                        dao.insertMessage(
                            ChatMessageEntity(
                                text = replyText,
                                sender = "MAHI",
                                language = detectLanguageTag(replyText),
                                isOffline = false,
                                isSynced = true
                            )
                        )
                        _statusText.value = "Answered by Gemini 3.5 Flash"
                        if (_voiceResponsesEnabled.value) {
                            ttsHelper.speak(replyText)
                        }
                    } else {
                        fallbackToOffline(trimmed, "No text in Gemini response. Used offline engine.")
                    }
                } catch (e: Exception) {
                    fallbackToOffline(trimmed, "Gemini network error: ${e.message ?: "fallback applied"}")
                }
            } else {
                val reason = if (!isOnline.value) "Offline Mode" else "Gemini API key not configured"
                fallbackToOffline(trimmed, reason)
            }

            _isGenerating.value = false
        }
    }

    private suspend fun fallbackToOffline(query: String, note: String) {
        val offlineAnswer = OfflineEngine.processQuery(query)
        dao.insertMessage(
            ChatMessageEntity(
                text = offlineAnswer,
                sender = "MAHI",
                language = detectLanguageTag(offlineAnswer),
                isOffline = true,
                isSynced = false
            )
        )
        _statusText.value = "Offline intelligence active ($note)"
        if (_voiceResponsesEnabled.value) {
            ttsHelper.speak(offlineAnswer)
        }
    }

    private fun buildSystemPrompt(): String {
        val langPreference = when (_selectedLanguage.value) {
            LanguageMode.HINDI -> "The user prefers answers strictly in Hindi (Devanagari script)."
            LanguageMode.ENGLISH -> "The user prefers answers strictly in English."
            LanguageMode.HINGLISH -> "The user prefers answers in Hinglish (Roman script Hindi mixed with English)."
            LanguageMode.AUTO -> "Detect the user's language: reply in Hindi/Hinglish if addressed in Hindi, reply in English if addressed in English."
        }

        return "You are Mahi AI Assistant, an empathetic, witty, and highly intelligent AI assistant inspired by a sleek dark black and hot-pink aesthetic. " +
                "You are fully bilingual in Hindi and English. " +
                "$langPreference " +
                "Keep answers voice-friendly, punchy, conversational, and direct (2-4 sentences for voice clarity unless detailed explanation is asked). " +
                "Avoid complex markdown tables or excessive bullet points that sound unnatural when spoken aloud."
    }

    private fun detectLanguageTag(text: String): String {
        for (char in text) {
            if (Character.UnicodeBlock.of(char) == Character.UnicodeBlock.DEVANAGARI) {
                return "hi"
            }
        }
        return "en"
    }

    fun clearHistory() {
        viewModelScope.launch {
            dao.clearAllMessages()
            _statusText.value = "Conversation history cleared"
        }
    }

    fun saveNote(title: String, content: String) {
        viewModelScope.launch {
            dao.insertNote(OfflineNoteEntity(title = title, content = content))
        }
    }

    fun deleteNote(id: Long) {
        viewModelScope.launch {
            dao.deleteNote(id)
        }
    }

    override fun onCleared() {
        super.onCleared()
        speechHelper.destroy()
        ttsHelper.shutdown()
    }
}
