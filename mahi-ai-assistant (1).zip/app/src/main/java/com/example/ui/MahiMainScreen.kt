package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LockClock
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.BottomController
import com.example.ui.components.MahiTopBar
import com.example.ui.screens.ConversationScreen
import com.example.ui.screens.OfflineVaultScreen
import com.example.ui.screens.VoiceCoreScreen
import com.example.ui.theme.BorderPink
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DeepWineContainer
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPinkGlow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MahiMainScreen(
    viewModel: MahiViewModel = viewModel()
) {
    val context = LocalContext.current
    val isPowerOn by viewModel.isPowerOn.collectAsState()
    val isOnline by viewModel.isOnline.collectAsState()
    val isListening by viewModel.isListening.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val soundLevel by viewModel.soundLevel.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val notes by viewModel.notes.collectAsState()
    val selectedLanguage by viewModel.selectedLanguage.collectAsState()
    val voiceResponsesEnabled by viewModel.voiceResponsesEnabled.collectAsState()
    val activeTab by viewModel.activeTab.collectAsState()
    val spokenTextLive by viewModel.spokenTextLive.collectAsState()
    val statusText by viewModel.statusText.collectAsState()

    // Permission launcher for microphone
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.toggleListening()
        } else {
            Toast.makeText(
                context,
                "Microphone permission is required for voice commands",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    val onMicAction = {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            viewModel.toggleListening()
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack),
        topBar = {
            MahiTopBar(
                isPowerOn = isPowerOn,
                isOnline = isOnline,
                voiceResponsesEnabled = voiceResponsesEnabled,
                onTogglePower = { viewModel.togglePower() },
                onToggleVoice = { viewModel.toggleVoiceResponses() },
                onClearHistory = { viewModel.clearHistory() },
                modifier = Modifier.statusBarsPadding()
            )
        },
        bottomBar = {
            BottomController(
                isPowerOn = isPowerOn,
                isListening = isListening,
                isSpeaking = isSpeaking,
                isGenerating = isGenerating,
                selectedLanguage = selectedLanguage,
                spokenTextLive = spokenTextLive,
                onLanguageChange = { viewModel.setLanguage(it) },
                onMicClick = { onMicAction() },
                onStopSpeaking = { viewModel.stopSpeaking() },
                onSendMessage = { viewModel.submitPrompt(it) }
            )
        },
        containerColor = CyberBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(CyberBlack)
        ) {
            // Mode Tab Switcher (Voice Core / Conversation / Offline Vault)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TabPill(
                    title = "Voice Orb",
                    icon = Icons.Default.GraphicEq,
                    isSelected = activeTab == MahiTab.VOICE_CORE,
                    onClick = { viewModel.setActiveTab(MahiTab.VOICE_CORE) },
                    modifier = Modifier.weight(1f)
                )

                TabPill(
                    title = "Chat (${messages.size})",
                    icon = Icons.Default.ChatBubbleOutline,
                    isSelected = activeTab == MahiTab.CONVERSATION,
                    onClick = { viewModel.setActiveTab(MahiTab.CONVERSATION) },
                    modifier = Modifier.weight(1f)
                )

                TabPill(
                    title = "Vault (${notes.size})",
                    icon = Icons.Default.Storage,
                    isSelected = activeTab == MahiTab.OFFLINE_VAULT,
                    onClick = { viewModel.setActiveTab(MahiTab.OFFLINE_VAULT) },
                    modifier = Modifier.weight(1f)
                )
            }

            // Tab Content
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                when (activeTab) {
                    MahiTab.VOICE_CORE -> {
                        val lastAiMsg = messages.lastOrNull { it.sender == "MAHI" }?.text
                        VoiceCoreScreen(
                            isPowerOn = isPowerOn,
                            isListening = isListening,
                            isSpeaking = isSpeaking,
                            isGenerating = isGenerating,
                            soundLevel = soundLevel,
                            statusText = statusText,
                            lastResponse = lastAiMsg,
                            onPromptSelected = { prompt ->
                                viewModel.submitPrompt(prompt)
                            }
                        )
                    }

                    MahiTab.CONVERSATION -> {
                        ConversationScreen(
                            messages = messages,
                            isGenerating = isGenerating,
                            onSpeakMessage = { text ->
                                viewModel.ttsHelper.speak(text)
                            }
                        )
                    }

                    MahiTab.OFFLINE_VAULT -> {
                        OfflineVaultScreen(
                            notes = notes,
                            onAddNote = { title, content ->
                                viewModel.saveNote(title, content)
                            },
                            onDeleteNote = { id ->
                                viewModel.deleteNote(id)
                            }
                        )
                    }

                    MahiTab.ABOUT -> {}
                }
            }
        }
    }
}

@Composable
private fun TabPill(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) DeepWineContainer else DarkSurfaceCard)
            .border(
                width = 1.dp,
                color = if (isSelected) NeonPink else BorderPink.copy(alpha = 0.3f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 8.dp, horizontal = 8.dp)
            .testTag("tab_${title.take(5)}"),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) NeonPinkGlow else TextMuted,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.size(6.dp))
            Text(
                text = title,
                color = if (isSelected) TextPrimary else TextSecondary,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}
