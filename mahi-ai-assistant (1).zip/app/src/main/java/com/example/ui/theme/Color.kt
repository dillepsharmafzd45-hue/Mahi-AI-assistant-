package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Mahi AI Theme - Midnight Cyber Black & Neon Hot Pink
val CyberBlack = Color(0xFF08080C)
val ObsidianBlack = Color(0xFF0D0D14)
val DarkSurface = Color(0xFF13131D)
val DarkSurfaceCard = Color(0xFF1A1A28)
val DarkSurfaceElevated = Color(0xFF222234)

// Neon & Soft Pinks
val NeonPink = Color(0xFFFF2A85)
val NeonPinkGlow = Color(0xFFFF4095)
val HotPink = Color(0xFFFF1493)
val BrightPink = Color(0xFFFF69B4)
val LightPinkGlow = Color(0xFFFFB6D9)
val DeepWineContainer = Color(0xFF38081F)
val BorderPink = Color(0x66FF2A85)

// Status & Accent
val NeonGreen = Color(0xFF00E676)
val StandbyGray = Color(0xFF5A5B6B)
val TextPrimary = Color(0xFFFBFBFE)
val TextSecondary = Color(0xFFB0B0C4)
val TextMuted = Color(0xFF747488)

// Secondary Cyan / Purple touches for holographic depth
val HologramPurple = Color(0xFF9C27B0)
val HologramPinkLight = Color(0xFFFF80BF)
