package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val MahiDarkColorScheme = darkColorScheme(
    primary = NeonPink,
    onPrimary = TextPrimary,
    primaryContainer = DeepWineContainer,
    onPrimaryContainer = LightPinkGlow,
    secondary = BrightPink,
    onSecondary = ObsidianBlack,
    secondaryContainer = DarkSurfaceElevated,
    onSecondaryContainer = LightPinkGlow,
    tertiary = HologramPinkLight,
    onTertiary = ObsidianBlack,
    background = CyberBlack,
    onBackground = TextPrimary,
    surface = ObsidianBlack,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceCard,
    onSurfaceVariant = TextSecondary,
    outline = BorderPink,
    outlineVariant = DarkSurfaceElevated
)

@Composable
fun MahiTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // Mahi AI always embraces the gorgeous dark black and neon pink identity
    val colorScheme = MahiDarkColorScheme
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = CyberBlack.toArgb()
                window.navigationBarColor = CyberBlack.toArgb()
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = false
                controller.isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
