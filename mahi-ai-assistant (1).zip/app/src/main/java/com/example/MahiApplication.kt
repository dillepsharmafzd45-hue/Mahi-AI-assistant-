package com.example

import android.app.Application
import com.example.data.local.MahiDatabase

class MahiApplication : Application() {
    val database: MahiDatabase by lazy {
        MahiDatabase.getDatabase(this)
    }

    override fun onCreate() {
        super.onCreate()
    }
}
